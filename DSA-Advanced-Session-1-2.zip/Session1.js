/*function LinearSearch(arr,key){
    var n = arr.length;
    for(var i =0;i<n;i++){
        if(arr[i]===key){
            return `ele is :- ${arr[i]} at:- ${i} index`
        }
    }
    return -1
}


var a = [1,8,4,11,16,13,12,44,56,77]
var b = 16;
// var b = 33;
console.log(LinearSearch(a,b))*/


function BinarySearch(arr,x,start,end){
    arr.sort()
    if(start > end){
        return false
    }
    var mid = Math.floor((start+end)/2);
   
    // 1st case
    if(arr[mid]== x){
        return true
    }
    //2nd case 
   else if(x>arr[mid]){
        return BinarySearch(arr,x,mid+1,end)
    }
    //3rd case
    else if(x<arr[mid]){
        return BinarySearch(arr,x,start,mid-1)
    }
    

}
var main_arr = [13,16,12,11,19]
var x = 66
// start = 0 index 
// end = main_arr.length-1

if(BinarySearch(main_arr,x,0,main_arr.length-1)){
    console.log("element found :-" , x)
}
else{
    console.log("element not found")
}














