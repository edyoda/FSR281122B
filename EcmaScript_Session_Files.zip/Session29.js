// vanilla javascript 

// for(var j =0;j<arr1.length;j++){
//     document.write(arr1[j]+"<br>");
// }


//es6 (Ecmascript)


// var arr1 = [11,12,13,14,15,16,17,18,19,20]

// // call back method 
// var fun1 = (element)=>{
//     document.write(element+"<br>");
// }

// function fun2(element,index,main_arr){
//     document.write(element+" :- "+index+" :- "+main_arr+"<br>");
// }

// arr1.map(fun1);
// arr1.map(fun2);

//anonymous fat arrow with map

// var arr2 = ["a","b","c","d"]
// arr2.map((element,index,main_arr)=>{
//     document.write(element+" :- "+index+" :- "+main_arr+"<br>")
// });
// arr2.map(function(x,y,z){
//     document.write(x+" :- "+y+" :- "+z+"<br>")

// });



// var arr3 = [20,21,22,23,24,25];
// console.log(arr3);
// // 20*5 ,21*5..etc
// var ans3 = arr3.map((element)=>{
//     return element*5
// })
// console.log(ans3);



// var arr4 = [20,21,22,23,24,25,26,27,28,29,30];
// console.log(arr4);
// var ans4 = arr4.filter((element)=>{
//     return element%2==0
// })
// console.log(ans4);




// var emp_info = [
//     {name : "john",email : "john@gmail.com",salary:60000},
//     {name : "tom",email :"tom@gmail.com",salary:95000}
// ]

// //only name 
// var emp_info_ans_1 = emp_info.map((element)=>{
// //    console.log(element)
// if(element.name == "john"){
//     console.log(element.name)
// }
//     return element.name
    
// })
// console.log(emp_info_ans_1);


// var emp_info_ans_2 =  emp_info.filter((element)=>{
//     return element.salary >70000
// })

// console.log(emp_info_ans_2);



// var arr5 = [16,12,18,14,20,16,17,18,19,20,21,23,25]
// var ans5 = arr5.find((element)=>{
//     return element%2!=0
// })
// console.log(ans5);

// //          0  1  2  3   4  5 6
// var arr5 = [16,12,18,14,20,16,17,18,19,20,21,23,25]
// var ans5 = arr5.findIndex((element)=>{
//     return element%2!=0
// })
// console.log(ans5);


// vanilla javascript 


// var arr6 = [1,2,3,4,5]
// // 1+2+3+4+5
// var sum = 0;
// for(var j =0;j<arr6.length;j++){
//     sum = sum + arr6[j] 

// }
// document.write(sum);



//es6 (Ecmascript)


// var arr7 = [1,2,3,4,5]
// var ans7 = arr7.reduce((count,element)=>{
//     return count = count + element
// },0)

// document.write("the sum is : "+ans7+"<br>");


// var arr8 = [1,2,3,4,5]
// // 1*2*3*4*5
// var ans8 = arr8.reduce((y,z)=>{
//     return y = y*z
// },1)

// document.write("the ans is :"+ans8+"<br>");

// var emp_info = [
//     {name : "john",email : "john@gmail.com",salary:60000},
//     {name : "tom",email :"tom@gmail.com",salary:95000}
// ]

// var ans9 = emp_info.reduce((count,element)=>{
//     return count = count + element.salary
// },0)
// document.write("total salary : "+ans9+"<br>");



var arr10 = ["abc","pqr","mno",11,12,13,14,15];
arr10.forEach((element)=>{
    // return element*10
    if(element%2==0){
        document.write(element+"<br>")
    }
})






















