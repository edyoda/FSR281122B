CREATE TABLE Demo2.Students(
Roll_no INT(3) NOT NULL AUTO_INCREMENT,
Std_Name VARCHAR(20),
Std_Email VARCHAR(30),
Dob DATE,
State_Code CHAR(2),
Std_Contact INT(10),
PRIMARY KEY(Roll_no)
);

SELECT * FROM Demo2.Students;

-- SELECT Roll_no,Std_name FROM Demo2.Students;

INSERT INTO Demo2.Students(Roll_no,Std_Name,Std_Email,Dob,State_Code,Std_Contact)
VALUES(1,"John","john@gmail.com","2002-08-03","MH",1234567898);

INSERT INTO Demo2.Students(Std_Name,Std_Email,Dob,State_Code,Std_Contact)
VALUES("tom","tom@gmail.com","2002-03-03","MH",1234567898);


INSERT INTO Demo2.Students(Std_Name,Std_Email,Dob,State_Code,Std_Contact)
VALUES("devika","devika@gmail.com","2002-06-03","MH",1234567898);








