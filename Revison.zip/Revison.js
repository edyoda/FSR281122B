class Node{
    constructor(element){
        this.element = element
        this.next = null

    }
}


class LinkedList{
    constructor(){
        this.head = null;
        this.size = 0;
    }

    add(element){
        let node = new Node(element);
        let current;

        if(this.head == null){
            this.head = node
        }
        else{
            current = this.head

            while(current.next){
                current = current.next
            }

            current.next = node;
        }
        this.size++

    }

    inserAt(element,index){
        if(index<0 ||index>this.size){
            console.log("wrong index")
        }
        else{
            let node = new Node(element);
            let curr , prev

            curr = this.head;
            if(index == 0){
                node.next = this.head
                this.head = node
            }

            else{
                curr =this.head;
                // console.log(curr)
                var it = 0;
                while(it<index){
                    it++
                    prev = curr;
                    console.log(prev)
                    curr = curr.next
                    // console.log(curr)
                }
                
                prev.next = node
                node.next = curr
            }

        }
    }

    printList(){
        let curr = this.head;
        let str = "";
        while(curr){
            str+=curr.element + " "
            curr=curr.next
        }
        console.log(str)
    }

}

let ll = new LinkedList();
ll.add(11)//0
ll.add(12)//1
ll.add(13)//2
ll.add(14)//3
ll.add(15)//4
ll.inserAt(70,3)
ll.printList();
console.log(ll)