// var a = document.getElementById('demo1').innerHTML;
// var a = document.getElementById('demo1').innerText;

// console.log(a);
// alert(a);

// function fun1(){
//     document.write("hello how are you ? <br>");
// }


// fun1();
// fun1();
// fun1();

// function fun2(){
    // console.log(document.getElementById('demo2'))
    // document.getElementById('demo2').innerText = "<b><i>new_para</i></b>";
    // document.getElementById('demo2').innerHTML = "<b><i>new_para</i></b>";
// }

// function fun3(){
//     var b = document.getElementById('input1').value;
//     // console.log(b)
//     // alert(b);
//     document.getElementById('demo3').innerHTML += b;
// }

// function fun4(){
//     document.getElementById('div1').innerHTML += "<img src='001-guarantee.png' class='img_style'>"
// }

// alert("hey 'dinesh'")








function fun5(){
    var x = document.getElementsByClassName('heading_style');
    console.log(x);
    // x[0].style.color = "navy";
    // x[0].style.backgroundColor = "pink";
    // x[0].style.borderRadius = "5px";
    // x[1].style.color = "red";
    // x[2].style.color = "yellow";

    for(var j =0;j<x.length;j++){
        x[j].className += " new_style"
        // console.log(x[j]);
        // x[j].style.color = "red"
      
    }

}

document.getElementById('link1').style.color = "red";
document.getElementById('link1').className = "new_style"








// var std_name1  = "john"
// var std_name2 = "tom"

// var stds_name = ["john","tom","alex","selena","sam"]




























