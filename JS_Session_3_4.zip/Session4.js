// var k = 12 + ""; //output is 12 as number 12 is converted to string
// console.log(k,typeof(k));


// var k = 12+13+"";
// console.log(k,typeof(k));


// var k = "15"*2; // output is 30 as string 15 is converted to number
// console.log(k,typeof(k));

// var k = "hello" + null;// output is null as null  is converted to string
// console.log(k,typeof(k));

// var k = 6+null;//output is 6 as null is converted to 0(number)
// console.log(k,typeof(k));

// var k = 12 + undefined;//output is NAN as undefined could not be converted to number
// console.log(k,typeof(k));

// var k = "hello" + undefined;
// console.log(k,typeof(k))

// // // true ----- 1
// // // false ------ 0

// var k = true + true; //1+1=2 output is 2 as true is converted to number
// console.log(k,typeof(k));


// var k = true -false // 1-0
// console.log(k,typeof(k));

// var k = false +10;
// console.log(k,typeof(k));

// var k = false +"10";
// console.log(k,typeof(k));


// var k = false + false
// console.log(k,typeof(k));

// var k = 12 == "12";
// console.log(k,typeof(k))

// var k = 13 === "13";
// console.log(k,typeof(k))

// // var k = true == true;
// var k = "true" == true;
// console.log(k,typeof(k));


// var k = "20";
// var ans1 = Number(k)
// console.log(ans1,typeof(ans1));


// var k = Number("");
// console.log(k,typeof(k))


// var k = Number(null);
// console.log(k,typeof(k));


// var k = Number(true);
// console.log(k,typeof(k));

// var k = Number(false);
// console.log(k,typeof(k));

// var k = Number(undefined);
// console.log(k,typeof(k));

// var k = String(25);
// console.log(k,typeof(k));

// var k = String(false);
// console.log(k,typeof(k));

// var k = String(0);
// console.log(k,typeof(k));


// var k = String(null);
// console.log(k,typeof(k));

// var k = String(undefined);
// console.log(k,typeof(k));

// var k = String(true);
// console.log(k,typeof(k));


// var k = Boolean(0);
// console.log(k,typeof(k));


// var k = Boolean(1);
// console.log(k,typeof(k));

// var k = Boolean(25);
// console.log(k,typeof(k));


// var k = Boolean(-25);
// console.log(k,typeof(k));


// var k = Boolean(null);
// console.log(k,typeof(k));


// var k = Boolean(undefined);
// console.log(k,typeof(k));

// var k = Boolean("Harsh");
// console.log(k,typeof(k));


// var x = 50;
// if(x==10){
//     document.write("x is 10");
// }
// else if(x==50){
//     document.write("x is 50")
// }   
// else if(x==60){
//     document.write('x is 60')
// }
// else{
//     document.write("value of x is "+x)
// }



// var y = prompt("Enter a num ")
// if(y>100){
//     document.write("value is grater than 100")
// }
// else if(y<100){
//     document.write("value is less than 100")
// }
// else{
//     document.write("sorry backup msg")
// }

// var z = prompt("Enter a num")
// if(z>0){
//     document.write("num is +ve")
// }
// else if(z<0){
//     document.write("num is -ve")
// }
// else if(z==0){
//     document.write("num is 0")
// }
// else{
//     document.write("sorry backup msg")
// }

// 5,6,7,8,9,10

// var num1 = 30;
// if(num1>=5 && num1<=10){
//     document.write("the num is in bet 5-10")
// }
// else if(num1==20 || num1==30){
//     document.write("the num is "+num1)
// }

var between_num = prompt("Enter your Number");
if(10 >= between_num >= 5){
    document.write("Your number is between given range");
}
else{
    document.write("Your number is out of range");
}









































