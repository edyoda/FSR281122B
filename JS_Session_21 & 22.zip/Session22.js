// $get();
var cartload = ()=>{
    $(document).ready(function(){
        $.get('https://fakestoreapi.com/carts',function(data,status){
            // console.log(data);
            // console.log(status);
            data.map((element)=>{
                // console.log(element)
                var div_tag = document.createElement('div');
                div_tag.className = "div_style"
                for(var i in element){
                    // document.write(i+" :- "+element[i]+"<br>");
                    div_tag.innerHTML += i+" :- "+element[i]+"<br>"
                
                }
                document.getElementById('demo1').appendChild(div_tag)
            })
        })

    })
   
}
cartload();

// // var data = [
// //     {},{},{},{}
// // ]


// $post()

var new_product = {
    id : 1,
    title : "red dress",
    image : "https://rukminim1.flixcart.com/image/612/612/xif0q/dress/l/z/j/s-36iqgwnred-iqraar-original-imagyxcfzrbaygqc-bb.jpeg?q=70",
    price : 1000,
    description : "Women Fit and Flare Red, Pink Dress"

}

$.post("https://fakestoreapi.com/products",new_product,function(data,status){
    // console.log(data);
    // console.log(status);
    for(var m in data){
        if(m=="image"){
        document.getElementById('img1').src = data[m];
        }
        else{
            document.getElementById('demo2').innerHTML += "<br>"+m+" : "+data[m]
        }
    }
})

























