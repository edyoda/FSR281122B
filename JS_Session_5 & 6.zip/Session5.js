/*var data = 12;
switch(data){
    case "a":
    document.write("inside case a <br>");
    break;
    case "b":
    document.write("inside case b <br>");
    break;
    case "c":
    document.write("inside case c <br>");
    case 12:
    document.write("inside case 12 <br>");
    break
    default:
    document.write("inside defualt case <br>");
}


var num1 = Number(prompt("Enter num1"));
var num2 = Number(prompt("Enter num2"));
var ans = num1 == num2;
console.log(ans);
switch(ans){
    case true :
    var final_add = num1 + num2
    document.write("the add is : "+final_add+"<br>" )
    break
    case false : 
    var final_sub = num1 - num2;
    document.write("the sub is :"+final_sub)

}

document.write("harsh");

var x = prompt("enter a letter");

var ans1 = x=="a" || x=="e" || x=="i" || x=="o" || x=="u";

switch(ans1){
    case true:
    document.write("it is vowel")
    break;
    case false:
    document.write("it is not a vowel")
    break;
}*/

var students_name = Array("john","tom","alex","sam","selena");
var students_marks = Array(20,30,40,10);
var city_name = ["California","Paris","Barcelona"];
// console.log(students_name)
// console.log(typeof(students_name))
// document.write(students_marks)
// console.log(city_name)
// document.write(city_name[0]+"<br>");
// document.write(city_name[1]+"<br>");
// document.write(city_name[2]+"<br>");
// document.write(city_name.length+"<br>");


//           0  1    2  -------------- 3 --------------------------   4   5                       
//                         0     1     ------- 2-----------   3
// var data = ["a","b","c",["xyz","pqr",["devika","ravi","jaya"],"mno"],"d","e"]
// document.write(data[5]+"<br>");
// document.write(data[3][1]+"<br>");
// document.write(data[3][2][2])
// e
// pqr

//       0  1  2 -------------------------3----------------------   4   5
//                  0  1   2   ------------3---------------------
 //                              0  1  -----2--------------
 //                                        0           1
 //                                                  012345     
// var z = [10,20,30,["a","b","c",[40,50,["Javascript","Python"]],"d"],60,70]
// document.write(z[4]+"<br>");
// document.write(z[3][0]+"<br>");
// document.write(z[3][3][2][0]+"<br>");
// document.write(z[3][3][2][1]+"<br>");
// document.write(z[3][3][2][1].slice(1,4)+"<br>");


// 60
// a
// javascript
//01234
// python 
// yth

// var city_info = [20.67,30.11,25];


// var city_info = {
//     "lat" : 20.67,
//     lon : 30.11,
//     temp : 25,

// }
// console.log(city_info)
// document.write(city_info.lat+"<br>");
// document.write(city_info.lon+"<br>");
// document.write(city_info.temp+"<br>");

// Array inside object

// var std_info = {
//     std_name : "john",
//     std_email : "john@gmail.com",
//     //                 0     1  
//     std_contact : [123456,98765432]
// }

// 98765432
// console.log(std_info)
// document.write(std_info.std_contact)
// document.write(std_info.std_contact[1]+"<br>")

console.log(undefined==null)
console.log(undefined===null)










































