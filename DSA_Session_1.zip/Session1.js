/*// method 1 
//Declaring, instantiating, initializing an Array

let arr1 = [1,2,3,4,5]

// method 2


let arr2 = new Array(11,12,13,14)

// insertion a value
let arr3 = []
arr3.push("hello")
console.log(arr3);

// Traversing
let demo_arr = ["devika","hima","akansha"]

let read_data = (element,index,main_arr)=>{
    // console.log(demo_arr)
    // console.log(element,index,main_arr)
    if(index == 3){
        document.write(main_arr)
    }
    else{
        document.write(element+"<br>");
    }
}

let arr4 = ["a","b","c","d"]
// map
arr4.map(read_data)
// arr4.forEach(read_data)*/



// let std_name = ["john","tom","alex","sam","selena"]
// std_name.forEach((element)=>{
//     console.log(element)
// })


// let nums =  [11,12,13,14,15]
// let ans1 = nums.map((element)=>{
//     return element*2
// })
// console.log(nums)
// console.log(ans1)


// let num2 = [11,12,3,5,8,9,11,2,3,1,2,3,4,5,6,7,13,14,15,16,17,18,19,20]
// //method 1
// let ans2 = num2.filter((element)=>{
//     return element<10
// })

// console.log(ans2)

// //method 2
// let ans3 = num2.find((element)=>{
//     return element<10
// })

// console.log(ans3)




// let arr5 = [2,5,7,4,6,1]
// let result1 = arr5.includes(4) 
// let result2 = arr5.includes(9)
// console.log(arr5) 
// console.log(result1) 
// console.log(result2) 







// class & Object

class Stack{
    constructor(){
        this.items = []
        this.length = 0;
        this.add = function(element){
            this.items.push(element)
            this.length +=1
        }
    }

    read(){
        console.log(this.items,this.length)
    }
}

let y = new Stack()
y.add(11)
y.add(12)
y.add("hello")
y.add("hi")
y.read();






















