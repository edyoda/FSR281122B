// var x = document.getElementsByTagName('p');
// console.log(x)
// for(var j = 0;j<x.length;j=j+1){
//     x[j].style.color = "red";
// }
// x[0].style.color = "red";
// x[1].style.color = "red";
// x[2].style.color = "red";

// function fun1(){
//     var x = document.getElementsByTagName('p');
// console.log(x)
// for(var j = 0;j<x.length;j=j+1){
//     x[j].style.color = "red";
// }
// }

// function fun2(){
//     var y = document.querySelectorAll('.box > b');
//     console.log(y);
//     for(var h=0;h<y.length;h=h+1){
//         y[h].style.color = "green";
//     }
// }

// document.querySelector('h1').style.color = "navy";
// document.querySelector('.heading_css').style.color = "navy";

// var n = document.querySelectorAll('.heading_css');
// for(var m =0;m<n.length;m=m+1){
//     n[m].style.color = "hotpink"
// }





// function fun3(){
// //   var z = document.getElementById('demo1').getAttribute('href')
// //   alert(z);
// // var z = document.getElementById('demo1').getAttribute('title')
// // alert(z);
// // var z = document.getElementById('demo1').getAttribute('color_name')
// // alert(z);
// // document.getElementById('demo1').style.color = z;

// // var z = document.getElementById('demo1').getAttribute('color_name');
// // console.log(z);
// // document.getElementById('demo1').style.color = z;

// var a_tag_attribute = document.getElementById('demo1').getAttribute('class');
// // alert(a_tag_attribute)
// document.getElementById('demo2').className += " "+ a_tag_attribute;

// }


// function fun4(){
// //   console.log(document.getElementsByClassName('img_style'))
// document.getElementsByClassName('img_style').setAttribute('src','img1.jpg')
//     // document.getElementById('img_id1').setAttribute("src","img1.jpg");
// }






// function fun5(){
//     var z = document.querySelectorAll('.link_div a');
//     // console.log(z)
//     var arr1 = []
//     for(var j =0;j<z.length;j=j+1){
//         z[j].setAttribute('href','https://fontawesome.com/')
//        arr1.push(z[j].getAttribute('title'))
//     }
//     document.getElementById('read_arr').innerHTML = arr1
// }





// Q.s 1 Create Live Alert Box
// Q.s 2 Create an Accordion with javascript
// Q.s 3.Convert month name to a number of days i.e January : 31 days 
// Q.s 4 Take 3 sides of the triangle as input from the user and check whether that triangle is equilateral, scalene or isosceles.















