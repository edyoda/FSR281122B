/*alert('hello');
prompt("Hey Enter your name ?");


alert(5432123456787);
alert("hello sahil");
alert("98989");
alert(true);
alert(false);

console.log("hello demo");
console.log(9876544567);
console.log(true);
console.log(false);


document.write("Hello");
document.write(3456789);
document.write(true);
document.write(false);*/


var user_name = "john";
var user_age = 18;

// document.write(user_name);
// document.write(user_age);

// alert(user_name);
// alert(user_age);


// console.log(user_name);
// console.log(user_age);


//my name is john and age is 12


document.write("my name is "+user_name+" and age is "+user_age);


var x = " hey";
var y = "how are you ?"
document.write(x+" "+y);



























