$(document).ready(function(){
    // $('p').filter(".p_style").css("background","green");
    // $('p').filter("div p").css("background","red");
    // $('p').filter("div+p").css("background","yellow");
    // $('p').filter("div ~ p").css("background","pink");
    // $('b').not(".b_style").css("color","navy");
    // $('i').eq(0).css("color","green");
    // $('i').eq(1).css("color","pink");
    // $('i').eq(2).css("color","blue");

    // $('.main_box1 button').first().css("background","red")
    // $('.main_box2 button').first().css("background","pink")
    // $('.main_box2 button').last().css("background","pink")
    // $('.main_box1 button').last().css("background","red")

    // $('#btn1').click(function(){
    //     $('#demo1').fadeIn("fast");
    //     $('#demo2').fadeIn();
    //     $('#demo3').fadeIn("slow");
    //     $('#demo4').fadeIn("5000");
       
    // })

    // $('#btn2').click(function(){
    //     $('#demo1').fadeOut("fast");
    //     $('#demo2').fadeOut();
    //     $('#demo3').fadeOut("slow");
    //     $('#demo4').fadeOut("5000");
    // })

    // $('#btn3').click(function(){
    //     $('#demo1').fadeToggle("fast");
    //     $('#demo2').fadeToggle();
    //     $('#demo3').fadeToggle("slow");
    //     $('#demo4').fadeToggle("5000");
    // })

    $('#demo5').click(function(){
        // $('#demo6').slideUp();
        // $('#demo6').slideUp("slow");
        // $('#demo6').slideUp("fast");
        // $('#demo6').slideUp(8000);
        // $('#demo6').slideDown();
        // $('#demo6').slideDown("fast");
        // $('#demo6').slideDown("slow");
        // $('#demo6').slideDown(9000);

        // $('#demo6').slideToggle();
        // $('#demo6').slideToggle("slow");
        // $('#demo6').slideToggle("fast");
        $('#demo6').slideToggle(9000);
    })

    $('#btn4').click(function(){
        $('#demo6').stop();
    })



});