// Binary search with Iterative Method

/*function IterativeFunction(arr,x){
    var start = 0;
    var end = arr.length-1
    while(start<=end){
        var mid = Math.floor((start+end)/2);
        if(arr[mid]==x) return true;
        else if(x>arr[mid]) start = mid + 1;
        else if(x<arr[mid]) end = mid - 1
    }

    return false;
}

//         0 1 2 3 4  5   6
var arr = [2,3,4,9,11,12,14]
var x = 11;

if(IterativeFunction(arr,x,0, arr.length-1)){
    console.log(" element is :-", x)
}
else{
    console.log(" element not found")
}*/

// 64 25 55 34 9 ;

// 25 64 55 34 9;


// 25 55 64 34 9;

// 25 55 34 64 9;

// 25 55 34 9 64 ;

// 9 25 34 55 64


/*

function BubbleSort(arr){

    var n = arr.length;
    for(var i = 0;i<n;i++){
        for(var j =0;j<n-1;j++){
            if(arr[j]>arr[j+1]){
                // we need to swap
                var temp = arr[j] //64
                arr[j] = arr[j+1] //  64 = 25
                arr[j+1] = temp   // 25 = 64
                // 25,64
                // console.log(arr)
            }
        }
    }

    console.log(arr)
}


BubbleSort([11,13,112,64, 25, 55, 34, 9])

// i = 64
// arr[j] = 64
// arr[j+1] = 25

// if(64>25){
//     swap it 
// }

*/






/* Selection Sort*/

/*

sorted |    unsorted 

            5 3 1 9 8 2 4 7


  1 | 3 5 9 8 2 4 7 
  1 2 | 5 9 8 3 4 7
  1 2 3 | 9 8 5 4 7
  1 2 3 4 | 8 5 9 7 
  1 2 3 4 5 | 8 9 7 
  1 2 3 4 5 7 | 9 8 
  1 2 3 4 5 7 8 | 9 
  1 2 3 4 5 7 8 9 | */



function SelectionSort(arr){
    var n = arr.length;
    for(var i = 0;i<n;i++){
        var min = i
        for(var j = i+1;j<n;j++){
            if(arr[j]<arr[min]){
                min = j 
            }
        }
        var temp = arr[min]
        arr[min] = arr[i]
        arr[i] = temp
        // console.log(arr)
    }
    console.log(arr)

}

SelectionSort([5,3, 1, 9, 8, 2, 4, 7])

// i = 0
// arr[i] = 5 
// arr[min] = 5 
// j = i+1 = 1
// j = 3
// arr[j]<arr[min]
// 3 < 5















































































