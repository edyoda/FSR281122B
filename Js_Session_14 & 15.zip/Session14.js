// this



// function fun1(x){
//     // console.log(x)
//     x.style.color = "red"
// }


// var person = {
//     std_name: "John",
//     std_email: "john@gmail.com",
//     std_contact: 987654,
//     read_data : function() {
//       return this.std_name + " " + this.std_email+" "+this.std_contact;
//     },
//     demo_name : "fatima"

//   };

//   document.write(person.read_data()+"<br>")
//   document.write(person.std_name)
//   document.write(person.std_contact)



// js Object ---> json String ---- JSON.stringify

// var demo_data = {
//     name : "abc",
//     email : "abc@gmail.com",
//     contact : [987654,9876567]
// }
// // console.log(typeof(demo_data))
// console.log(demo_data,typeof(demo_data))
// // js Object ---> json String ---- JSON.stringify
// var final_json = JSON.stringify(demo_data)
// console.log(final_json,typeof(final_json))
// // for(var i in final_json){
// //     console.log(i)
// // }

// // JSON.string ----- js Object --- JSON.parse
// var final_obj = JSON.parse(final_json)
// console.log(final_obj,typeof(final_obj))




function read_post(){
    var a = new XMLHttpRequest();
    a.open("GET","https://jsonplaceholder.typicode.com/posts",true);
    a.send();
    a.onreadystatechange = function(){
        console.log(this.readyState);
        // console.log(this.status)
        if(this.status==200 && this.readyState == 4){
            // console.log(this.responseText)
            // console.log(typeof(this.responseText))
            // document.write(this.responseText)
            var final_data = JSON.parse(this.responseText)
            console.log(final_data)

        }
    }


}

read_post();    




























