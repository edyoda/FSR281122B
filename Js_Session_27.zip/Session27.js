// //main class
// class Employee{
//     constructor(name,email,job_profile,joining_date){
//         this.name_pro = name;
//         this.email_pro = email;
//         this.profile_pro = job_profile;
//         this.date_pro = joining_date;
//     }
//     emp_name_email(){
//         return "emp name is "+this.name_pro+ " and emp email is "+this.email_pro+'<br>'
//     }
//     profile_info(){
//         return " emp job profile is "+this.profile_pro+" and emp joining date is "+this.date_pro+"<br>";
//     }
// }

// //child class / sub class
// class Designer extends Employee{
//     constructor(name,email,job_profile,joining_date,tool){
//       super(name,email,job_profile,joining_date);
//       this.tool_pro = tool
//     }
//     final_reading(){
//         return super.emp_name_email()+ super.profile_info() + "tool name is :" +this.tool_pro+"<br>";
//     }
// }

// var tom = new Designer("tom","tom@gmail.com","ui/ux","7/02/2023","photoshop")
// // console.log(tom);
// console.log(tom.final_reading());



// // child class / sub class
// class Programmer extends Employee{
//     constructor(name,email,job_profile,joining_date,language,tool="no idea"){
//         super(name,email,job_profile,joining_date)
//         this.language_pro = language;
//         this.tool_pro = tool;
//     }

//     final_reading(){
//         return super.emp_name_email()+ super.profile_info() + "language name is :" +this.language_pro+" for tool "+ this.tool_pro+"<br>";
//     }

// }

// var john = new Programmer("john","john@gmail.com","python_dev","07/02/2023","python","photoshop");
// console.log(john.final_reading());



// Animal -- name
//     dog  -- breed
//     cat  -- breed


class Person{
    constructor(data){
        if(this.constructor == Person){
            this.val = data
            throw new Error("you cannot use main class constructor or other methods")
        }
    }
    info(){
        throw new Error("cannot read info from abstract class")
    }
    demo(){
        console.log("hello"+this.val)
    }
}
class Teacher extends Person{
    constructor(data){
        super(data)
    }
    info(){
        // super.info();
        console.log("she is maths teacher")
        super.demo();
    }

}
var teacher1 = new Teacher("selena")
teacher1.info();
var teacher2 = new Person("alex");
// teacher2.info();
teacher2.demo()


































