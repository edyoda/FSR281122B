// var p_tag_var = document.getElementById('demo1');
// console.log(p_tag_var);


// console.log(document.getElementById('demo1').innerHTML)

// document.getElementById('demo1').innerHTML = "new para"

// document.getElementById('demo2').innerHTML = "<h1>hello</h1> <button>demo btn</button>"




// // var y = document.getElementById('demo3').innerHTML
// var y = document.getElementById('demo3').innerText
// alert(y)



// var num1 = "2";
// var num2 ="3";
// var num1 = 2;
// var num2 = 3;
// var data = "hello"
// var final_ans = num1+num2+data;
// var final_ans = data+num1+num2
// document.getElementById('ans1').innerHTML = final_ans;

// document.getElementById('ans1').innerHTML = final_ans;


// var num4 = 12;
// var num5 = 2;
// var data = "hello"
// // document.getElementById('ans2').innerHTML = num4*num5+data;

// // document.getElementById('ans2').innerHTML = data+num5*num4;

// document.getElementById('ans2').innerHTML = data*num4-num5;



// var data1 = prompt("Enter no 1");
// var data2 = prompt("Enter no 2");
// var my_ans = data1/data2

// document.getElementById('ans3').innerHTML = my_ans



// document.getElementById('btn1').innerHTML = "new btn";

//               12345678910
//               01234567891011   
// var demo_str1 = "hello world"
// console.log(demo_str1[0]+demo_str1[1]+demo_str1[2]+demo_str1[3]);
// console.log(demo_str1);
// console.log(typeof(demo_str1))
// console.log(demo_str1.length)

// var z = 12;
// console.log(typeof(z));

//          0123456789
// var str1 = "hello world"
// // var ans1 = str1.slice(6)
// var ans1 = str1.slice(1,4)

// console.log(ans1)

// var demo_str2 = "we are learning javascript"

// console.log(demo_str2[16]+demo_str2[17]+demo_str2[18]+demo_str2[19]);
// console.log(demo_str2.slice(16,20))
//                       -4 -3-2-1
// var str2 = "hellop javascript"
// console.log(str2.slice(-1));
// console.log(str2.slice(-8,-2))

// var str3 = "hello javascript"
// console.log(str3.substring(0,4))
// console.log(str3.sub(string(-2))
// console.log(str3.substr(-3));



var s = null
console.log(s);






