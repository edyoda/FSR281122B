function fun1(){
    var li_tag = document.createElement('li');
    var li_text = document.createTextNode('xyz');
    // <li></li> xyz
    // <li>xyz</li>
    // console.log(li_tag,li_text);
    li_tag.appendChild(li_text);
    // console.log(li_tag)
    document.getElementById('list1').appendChild(li_tag);
}
// function fun2(){
//     for(var j = 1;j<=10;j=j+1){
//         var img_tag = document.createElement('img');
//         // console.log(img_tag)
        // img_tag.src ="img1.jpg"
//         img_tag.className ="img_style"
//         // console.log(img_tag)
//         document.getElementById('demo1').appendChild(img_tag)
//     }
// }
// fun2();


// function fun3(){
//     var img_data = ['bg2.png','img1.jpg','Reference_Image.png']
//     for(var j =0;j<img_data.length;j=j+1){
//         // console.log(j)
//         // console.log(img_data[j])
//         var img_tag = document.createElement('img');
//         img_tag.src = img_data[j];
//         img_tag.className = "img_style"
//         // console.log(img_tag);
//         document.getElementById('demo2').appendChild(img_tag);

//     }

// }
// fun3();


// function fun4(){
//     var ul = document.getElementById('list2');
//     // console.log(ul)
//     var temp_var = ul.childNodes[0];
//     // var temp_var = ul.childNodes;
//     // console.log(temp_var);
//     ul.removeChild(temp_var);
//     // ul.remove();
// }

// function fun5(x){
// //    console.log(x)
// //   console.log(document.getElementById(x))
// document.getElementById(x).remove();
// }


function remove_row(){
    var x = document.getElementById('Child_btn');
    // console.log(x.parentNode.parentNode)
    var row = x.parentNode.parentNode
    // console.log(row.parentNode);
   row.parentNode.removeChild(row)
// row.remove();
    // document.getElementById('row1').remove();
}



// var emp_info = {
//     emp1 : {
//         name : "tom",
//         email : "tom@gmail.com",
//         contact : 987654
//     },
//     emp2 : {
//         name : "john",
//         email : "john@gmail.com",
//         contact :45678
//     },
//     emp3 : {
//         name : "alex",
//         email : "alex@gmail.com",
//         contact : 2345678
//     }
// }

var max_val;
function max_num(a,b,c){
    if(a>b && a>c){
        // document.write("max num is a")
        max_val = a;
    }
    else if(b>a && b>c){
        max_val = b
    }
    else if(c>a && c>b){
        max_val = c
    }
    else{
        max_val = "sorry wrong data"
    }
    return max_val
}
// var res = max_num(12,13,"xyz");
var res = max_num(12,13,20);
document.write(res)


