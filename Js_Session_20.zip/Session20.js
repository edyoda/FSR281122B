// document.getElementById('demo1').className

// $(document).ready(function(){
    // console.log("hey");
    // console.log($('#demo1'))
    // console.log($('.abc'));
    // console.log($('p'));

    // $('#div1').css("color","blue");
    // $('#div1').css("border","2px solid black");
    // $('#div1').css("height","100px");
    // $('#div1').css("width","200px");


    // $('#div2').addClass("xyz pqr mno");

    // $('#btn1').click(function(){
    //     $('#div3').addClass('img_style');
    // })



// });

// var x = document.getElementById('btn1');
// x.addEventListener("click",function(){

// })




$(document).ready(function(){
    // $('#div4').mouseover(function(){
    //     $('#div4').css("background","blue")

    // })

    // $("#div4").mouseout(function(){
    //     $("#div4").css("background","green")
    // })

    // $('#btn2').click(function(){
    //     $('#img1').hide();
    // })
    // $("#btn3").click(function(){
    //     $('#img1').show();
    // })

    // $('#btn4').click(function(){
    //     $('#img1').toggle();
    // })

    // $("#btn5").click(function(){
    //     $('div p').toggleClass("p_style"); //similar to toggle method
    //     $('div p').addClass("bg_color1") // similar to show
    //     $('div p').removeClass("mno"); // similar to hide 
    // });

    $("div #btn6").click(function(){
        $('#demo11').addClass("b_tag_class2")
    })

    $('div #btn7').click(function(){
        $('#demo11').removeClass("b_tag_class2")
    })

    $('div #btn8').click(function(){
        $('#demo11').toggleClass("b_tag_class2");
    })

})



































