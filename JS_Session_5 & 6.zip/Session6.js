
// document.write('object inside box 1 <br>');
// document.write('object inside box 2 <br>');
// document.write('object inside box 3 <br>');
// document.write('object inside box 4 <br>');
// document.write('object inside box 5 <br>');

//   ----1----  --2--- ---4----
// for(var box = 1;box<=5;box=box+1){
//     document.write("object is inside box "+box+"<br>"); //-----3----
// }



// for(var box = 5;box>=1;box = box -1){
//     document.write("object is inside box "+box+"<br>")
// }



// 10
// 20
// 30
// 40
// 50
// 60
// 70
// 80
// 90
// 100

// for(var j = 10;j<=100;j=j+10){
//     document.write(j+"<br>")
// }


// 10*1=10
// 10*2=20
// 10*3=30

// ...

// 10*10=100

// for(var y=1;y<=10;y = y +1){
//     document.write(10*y+"<br>")
// }


// for(var y=1;y<=10;y = y +1){
//     document.write(25*y+"<br>")
// }

//          0123345
//          12345
// var data = "hello javascript is fun";
// h
// e
// l
// l
// o 

// j
// a
// v
// a
// s
// c 
// r 
// i 
// p 
// t

// for(var j =0;j<data.length;j=j+1){
//     document.write(data[j]+"<br>")
// }
// h 
// i 
// r 
// a 
// l 






// document.write(data[0]+"<br>");
// document.write(data[1]+"<br>");
// document.write(data[2]+"<br>");
// document.write(data[3]+"<br>");
// document.write(data[4]+"<br>");
// document.write(data[5]+"<br>");
// document.write(data[6]+"<br>");
// document.write(data[7]+"<br>");
// document.write(data[8]+"<br>");
// document.write(data[9]+"<br>");
// document.write(data[10]+"<br>");
// document.write(data[11]+"<br>");
// document.write(data[12]+"<br>");
// document.write(data[13]+"<br>");
// document.write(data[14]+"<br>");
// document.write(data[15]+"<br>");



// var user_input = prompt("Enter your name ");
// for(var j =0;j<user_input.length;j=j+1){
//     document.write(user_input[j]+"<br>")
// }




//          0       1    2    3   4     5    6  7     8      9
// var arr1 = ["abc","pqr","xyz",567,987,"mno",543,1234,"demo1","demo2"]
// document.write(arr1[0]+"<br>")
// document.write(arr1[1]+"<br>")
// document.write(arr1[2]+"<br>")
// document.write(arr1[3]+"<br>")
// document.write(arr1[4]+"<br>")
// document.write(arr1[5]+"<br>")
// document.write(arr1[6]+"<br>")
// document.write(arr1[7]+"<br>")



// for(var y =0;y<arr1.length;y = y +1){
//     document.write(arr1[y]+"<br>")
// }
//         0   1  2
var num = [11,12,13,14,15,16]

for(var y =0;y<num.length;y=y+1){
    // document.write(num[y])
    if(num[y]%2==0){
        document.write("num is even "+num[y]+"<br>")
    }
    else if(num[y]%2!=0){
        document.write("num is odd "+num[y]+"<br>")
    }
}



var data = [11,12,13,14,15,16,17,18,19,20,21,25]

// div by 5 & 3 both
// div by 5
// div by 3

for(var k = 0;k<data.length;k=k+1){
    if(data[k]%5==0 && data[k]%3==0){
        document.write("the num is div by both "+data[k]+"<br>")
    }
    else if(data[k]%5==0){
        document.write("the num is div by 5 "+data[k]+"<br>")
    }
    else if(data[k]%3==0){
        document.write("the num is div by 3 "+data[k]+"<br>")
    }
}







