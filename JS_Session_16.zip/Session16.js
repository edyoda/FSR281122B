// var postObj = {
//     id : 1,
//     title : "hello javascript",
//     body : "we are doing ajax in js",
//     img : "img1.jpg"
// }
// // console.log(typeof(postObj))
// var post = JSON.stringify(postObj);
// // console.log(typeof(post))


// var url = "https://jsonplaceholder.typicode.com/posts";
// var a = new XMLHttpRequest();
// a.open("POST",url,true);
// a.setRequestHeader("content-type","application/json");
// a.send(post);
// a.onreadystatechange = function(){
//     if(this.status == 201 && this.readyState ==4){
//         console.log("post created !")
//         console.log(this.responseText)
//     }
// }


// window.document.write("hey devika ");
// document.write("1234");
// part of window Object
// var num1 = 12;
// var obj1 = {};
// var arr1 = ["a","b","c"];
// alert("hey");
// prompt("enter");
// function fun2(){
//     alert("hey jaya")
// }


// window = {
//     num1 : 12,
//     arr1  : ["a","b","c"],
//     fun2 = function()

// }


// document.write(window.screen.availHeight+"<br>"+window.screen.availWidth+"<br>")
// document.write(window.innerHeight+"<br>"+window.innerWidth+"<br>");
// document.write(screen.colorDepth+"<br>");
// document.write(location.href+"<br>");
// document.write(location.host+"<br>");
// document.write(location.hostname+"<br>");
// document.write(location.pathname+"<br>");
// document.write(location.protocol+"<br>");
// document.write(location.port+"<br>");

// document.write(history.back()+"<br>");
// document.write(history.forward()+"<br>");


function count_fun(){
    if(typeof(Storage)!== "undefined"){
        if(localStorage.clickcount){
            localStorage.clickcount = Number(localStorage.clickcount)+1;
        }
        else{
            localStorage.clickcount = 1;
        }

        document.getElementById('div1').innerHTML = "count is  "+localStorage.clickcount
    }
    else{
        document.getElementById('div1').innerHTML += "sorry browser dose not support localstorage"
    }
}

function clear_count_fun(){
    window.localStorage.clear();
}





















































