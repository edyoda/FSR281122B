

// var user_name = "hiral";
// for(var y=0;y<user_name.length;y = y+1){
//     // document.write(user_name[y]+"<br>")
//     if(user_name[y]=="a"|| user_name[y]=="e" || user_name[y]=="i"||user_name[y]=="o" || user_name[y]=="u"){
//         document.write(user_name[y]+"<br>")
//     }
// }

// var obj1 = {
//     lat : 12.11,
//     lon :14.23,
//     temp : 25
// }
// obj1.temp = 40
// document.write(obj1.lat+"<br>"+obj1.lon+"<br>"+obj1.temp+"<br>");

// // object literal


// var obj2 = {
//     std_name : "john"
// };
// obj2.std_name = ["selena","john","tom"];
// obj2.std_age = "20";
// obj2.std_email = "selena@gmail.com"
// // console.log(obj2);
// document.write("std name is :"+obj2.std_name+"<br>");
// document.write("std age is :"+obj2.std_age+"<br>");
// document.write("std email is :"+obj2.std_email+"<br>");


//new Object()


// var emp_info = new Object();
// emp_info.emp_name = "tom";
// emp_info.emp_email = "tom@gmail.com";
// // console.log(emp_info);
// // document.write(emp_info.emp_name)

// document.write(Object.entries(emp_info)+"<br>");
// document.write(Object.keys(emp_info)+"<br>");
// document.write(Object.values(emp_info)+"<br>");

// var city_info = {
//     lat : 12.11,
//     lon :14.23,
//     temp : 25
// }

// document.write(Object.entries(city_info)+"<br>")
// document.write(Object.keys(city_info)+"<br>")
// document.write(Object.values(city_info)+"<br>");









// var city_info = {
//     lat : 12.11,
//     lon :14.23,
//     temp : 25
// }
// // for in loop
// for(var i in city_info){
//     // console.log(i)
//     // console.log(city_info[i])
//     document.write(i+" ----- "+city_info[i]+"<br>")
// }


// var emp_info = {
//     emp1 : {
//         name : "tom",
//         email : "tom@gmail.com",
//         contact : 987654
//     },
//     emp2 : {
//         name : "john",
//         email : "john@gmail.com",
//         contact :45678
//     },
//     emp3 : {
//         name : "alex",
//         email : "alex@gmail.com",
//         contact : 2345678
//     }
// }

// for(var x in emp_info){
//     // console.log(emp_info[x])
//     for(var y in emp_info[x]){
//         // console.log(y)
//         // console.log(emp_info[x][y])
//         document.write(y+" ---- "+ emp_info[x][y]+"<br>")
//     }

//     document.write(" ***************** <br>")
// }




// var car_obj = {
// 	name : "john",
// 	email : "john@gmail.com",
// 	car_list : {      //   0        1        2        3       
// 		most_fav_car :  ['Audi', 'Toyota',"Bugatti","Volvo"]
														
// 	}
// }

// for(var j in car_obj.car_list){
//     // document.write(car_obj.car_list[j])
//     // document.write(car_obj.car_list[j].length)
//     for(var k =0;k<car_obj.car_list[j].length;k = k+1){
//         document.write(car_obj.car_list[j][k]+"<br>")
//     }
// }



// Audi
// Toyota
// Bugatti
// Volvo



// while loop

// var j = 1; // 1
// while(j<=10){ // 2
//     document.write(j+"<br>"); // 3
//     j = j +1 // 4
// }
// //  1           2    4
// for(var j = 1;j<=10;j=j+1){
//     document.write(j+"<br>") // 3
// }


// do while


// var j = 1;
// do{
//     document.write("hey "+j+"<br>");
//     j = j +1
// }
// while(j <=20);



// var x = prompt("how many candies you want ?");
// var i = 1;
// var av = 5;
// while(i<=x){
//     if(i>av){
//         document.write("sorry out of stock <br>");
//         break;
//     }
//     document.write('candy '+i+"<br>");
//     i = i +1
// }


// var arr1 = [11,12,13,14,16,12,17,18,11,4,2,19,20]
// for(var j = 0;j<arr1.length;j=j+1){
//     // document.write(arr1[j]+"<br>")
//     if(arr1[j]<15){
//         document.write(arr1[j]+"<br>")
//     }
//     else{
//         // document.write(arr1[j]+" sorry <br>")
//         // break
//         continue;
//     }
// }






//          0      1      2     3
var arr2 = ["abc","pqr","xyz","mno"]
// var ans2 = arr2.reverse();
// var ans2 = arr2.join(" ");
// var ans2 = arr2.join("*");
// var ans2  = arr2.pop()
// document.write(ans2+"<br>");
// arr2.shift();
// arr2.push("new_data1");
// arr2.unshift("new_data2");
// var new_a = [11,12]
// var new_b = [13,14]
// var new_c = arr2.concat(new_a,new_b);
// document.write(new_c+"<br>")
// document.write(arr2+"<br>");
// var res = arr2.slice(1)
// var res = arr2.slice(1,3)
// document.write(res+"<br>")
// arr2.splice(1,0,"demo1");
arr2.splice(2,1)
arr2.splice(2,2)

document.write(arr2+"<br>");












