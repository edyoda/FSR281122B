// var num1 = 12;
// document.write(num1+"<br>");
// var num1 = 13;
// document.write(num1+"<br>");

// let num2 = 15;
// document.write(num2+"<br>");
// // let num2 = 16;
// let num3 = 16;
// document.write(num3+"<br>");


// // ----- let (block scope) and var(global scope) const(block scope)-----


// let str2 = 'hi aditya';
// document.write(str2+"<br>")

// function fun1(){
//     var str1 = "hello devika";
//     document.write(str1+"<br>")
//     var str1 = "hello fatima";
//     document.write(str1+"<br>");

//     let str2 = "hi prashant"
//     document.write(str2+"<br>");
//     // let str2 = 'hi aditya';
//     // document.write(str2+"<br>")

// }


// fun1();




// var x = "main_database(ecom)"
// x = "new_database";
// document.write(x+"<br>");

// var y = 12;
// y = 13;
// document.write(y+"<br>");


// let z = "amazon_psw@3434565";
// z= "new_psw@123";
// document.write(z+"<br>");


// let contact_no = 12345;
// contact_no = 909090
// document.write(contact_no+"<br>");


// const database_psw = 112233;
// // database_psw = 778899;
// document.write(database_psw+"<br>");

// //const database_psw = 34544; // cannot use same var name 
// // with const you cannot reassign the val also you cannot reuse the var name

// function fun2(){
//     const  database_psw = "hey@123"
//     document.write(database_psw+"<br>")
//     // var database_psw = "hima@123"
 
// }

// fun2()

// var emp_name = "john";
// var emp_email = "john@gmail.com"
// // emp name is john and email is john@gmail.com
// document.write("emp name is "+emp_name+" and email is"+emp_email+"<br>");


// let std_name = "tom";
// let std_email = "tom@gmail.com";
// // std name is tom and email is tom@gmail.com
// document.write(`<b class="abc">std name is ${std_name} and email is ${std_email}<br></b>`)







// find
// findIndex
// reduce
// forEach
// map 
// filter

// let read_arr1 = (element,index,main_arr)=>{
//     document.write(`${element} :--- ${index} :--  ${main_arr} <br>`)
// }

// let arr1 = [11,12,13,14,15,16,17,18,19,20]
// arr1.map(read_arr1);

// let ans1 = arr1.map((element)=>{
//     return element*10
// });
// document.write(ans1);
// // console.log(ans1);
// // ans1 = [110,120,130,140....]
// for(let n of ans1){
//     document.write(n+"<br>");
// }
// for in ---- obj
// for of --- array
// for(var z =15;z<140;z=z+3);

let arr2 = [11,12,13,14,15,16,17,18,19,20]
let ans2 = arr2.filter((element,index,main_arr)=>{
    // console.log(element,index,main_arr)
    return element%2==0
})

// document.write(ans2);

for(var m of ans2){
    document.write(`${m} <br>`)
}





















































