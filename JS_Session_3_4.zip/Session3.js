// var x = "hello";
// var y = 12345;
// alert(x+y);

// var str1 = "hello";
// var str2= "javascript";
// var str3 = "demo"
// var ans1 = str1.concat(str2,str3,str1);
// alert(ans1);


// var str4 = "hello javascript";
// var str4 = "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Dolorum nam modi quaerat voluptates voluptatibus amet laudantium officia pariatur aliquid dignissimos, asperiores maiores ullam iusto laboriosam excepturi optio! Obcaecati, quos accusantium"
// var ans2 = str4.startsWith("hello");
// var ans2 = str4.endsWith("javascript");
// var ans2 = str4.startsWith("adipisicing");

// var ans2 = str4.startsWith("Lorem ipsum, dolor sit amet");
// var ans2 = str4.endsWith("javascript");
// alert(ans2);



// var str5 = " AB "
// var str6 = " CD "
// var ans3 = str5 + str6;
// var ans3 = str5.trim() + str6.trim();
// alert(ans3);




// var user_name = prompt("Enter a data");
// console.log(user_name.trim());



// var str7 = "a BLUE Blue Blue Blue  bottle with blue liquid is on blue blue blue blue blue blue table"
// var ans4 = str7.replace(/blue/,"green");
// var ans4 = str7.replace(/blue/i,"green");
// var ans4 = str7.replace(/blue/g,"green");
// var ans4 = str7.replace(/blue/gi,"green");
// var ans4 = str7.replace(/Blue/g,"green");

// alert(ans4);

        //       6789 .....
// var str8 = "hello demo demo demo javascript d d d d d"
// var ans5 = str8.indexOf("demo");
// var ans5 = str8.lastIndexOf("Demo");
// alert(ans5);


// var str9 = "HELLO";
// var ans6 = str9.toLowerCase();
// alert(ans6);

// var str10 = "javascript";
// var ans7 = str10.toUpperCase();
// alert(ans7);

// var str11 = "hello javascript"
// var ans8 = str11.charAt(6);
// alert(ans8);

// var str12 = prompt("enter upper case we convert to lower case")
// var ans9 = str12.toLowerCase();
// console.log(ans9);



// var m = 11;
// var n = 12;
// var m = "abc";
// var n = "pqr";
// var m = "12";
// var n = 12;
// var x = 13;
// var k = m == n;
// var k = m<n;
// var k = n>m;
// var k = n>=m;
// var k = m<=n;
// var k = m == n
// var k = m == n;
// var k = m === n; 
// var k = n != x;
// alert(k);


/*There are two types of coercion in JavaScript:

1) Implicit Coercion: Type conversion is done by JavaScript is Implicit Coercion.

2) Explicit Coercion: Type conversion is done in code using the inbuilt functions 
like Number(), String(), Boolean(), etc is Explicit Coercion.*/


// var num1 = Number(prompt("Enter num1"))
// var num2 = Number(prompt("Enter num2"))
// console.log(typeof(num1,num2))
// // var final_ans = Number(num1) + Number(num2)
// var final_ans = num1 + num2;
// console.log(final_ans)


var num3 = "2";
var num4 = "2";
console.log(num3*num4); //Implicit Coercion
console.log(Number(num3)+Number(num4)); //Explicit Coercion

















































