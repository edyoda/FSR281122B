-- LIKE

SELECT * FROM World_x.Country;

-- ******* select all the country name starting with I ******

SELECT * FROM World_x.Country WHERE Name LIKE "I%";


-- ******* select all the country name Ends with I ******

SELECT * FROM World_x.Country WHERE Name LIKE "%I";

-- ******* select all the country name starting with AU ******

SELECT * FROM World_x.Country WHERE Name LIKE "Au%";

-- ******* select all the country name ends with LAND ******

SELECT * FROM World_x.Country WHERE Name LIKE "%land";

-- ******* select all the country name with 2nd char is A ******

SELECT * FROM World_x.Country WHERE Name LIKE "__a%";

-- di - 3,4

SELECT * FROM world_x.country WHERE name LIKE "%a_";

SELECT * FROM World_x.Country WHERE Name LIKE "__di%";


SELECT * FROM World_x.Country;

SELECT * FROM World_x.country ORDER BY Name DESC;

SELECT * FROM World_x.country ORDER BY Name ASC;

-- DESC with Capital

SELECT * FROM world_x.country ORDER BY Capital DESC;

-- capital <100 DESC


select * from world_x.country where Capital<100 order by Capital desc;

-- count


SELECT COUNT(ID) FROM World_x.City;


SELECT COUNT(Name) FROM World_x.Country;

SELECT * FROM World_X.Country LIMIT 0,5;


SELECT * FROM World_x.City LIMIT 10,15;

SELECT * FROM World_x.City LIMIT 0,5;




