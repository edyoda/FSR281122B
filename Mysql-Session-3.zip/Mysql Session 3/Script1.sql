SELECT * FROM Company.Emp_info;

SELECT MAX(Emp_Salary) From Company.Emp_info;

SELECT MIN(Emp_Salary) From Company.Emp_info;

SELECT AVG(Emp_Salary) From Company.Emp_info;

SELECT SUM(Emp_Salary) From Company.Emp_info;

SELECT COUNT(Emp_Salary) FROM Company.Emp_info;


select count(emp_salary) from company.emp_info where Emp_Salary < 50000;

SELECT  * FROM company.emp_info WHERE Emp_Salary>"20000" AND Emp_Profile="HR";

SELECT  COUNT(emp_salary) FROM company.emp_info WHERE Emp_Salary>"20000" AND Emp_Profile="HR";


-- hr - 2
-- marketing -2
-- software dev - 1
-- tester - 1


SELECT Emp_Profile,COUNT(Emp_salary) FROM Company.Emp_info GROUP BY Emp_Profile;


SELECT Emp_Profile,COUNT(Emp_Id) FROM Company.Emp_info  GROUP BY Emp_Profile HAVING COUNT(Emp_Profile)>1;











