// function fun1(){
//     // document.getElementById('demo1').style.background = "pink";
//     document.getElementById('demo1').style.backgroundImage = "url(img1.jpg)"
//     document.getElementById('demo1').style.backgroundSize = "cover";
// }

// function fun2(){
//     // document.getElementById('demo1').style.background ="darkred";
//     document.getElementById('demo1').style.backgroundImage = "url(Reference_Image.png)"
//     document.getElementById('demo1').style.backgroundSize = "cover";

// }


// function fun3(){
//     document.getElementById('demo2').style.background = "lightblue"
// }

// function fun4(){
//     document.getElementById('demo2').style.background = "red"
// }



// function fun3(){
//     // document.getElementById('demo3').style.background  = "yellow"
//     document.getElementById('demo3').style.backgroundImage = "url(img1.jpg)"
//    document.getElementById('demo3').style.backgroundSize = "cover";
// }

// function fun4(){
//     document.getElementById('demo4').style.background = "navy"
//     document.getElementById('demo4').style.color = "white"
//     // document.getElementById('p1').innerHTML = "text copied !"
//     document.getElementById('p1').style.display = "block";

// }

// function fun5(){
//     document.getElementById('textarea1').style.background = "pink"
// }


// function fun6(){
//     document.getElementById('input1').style.color = "darkred";
//     var x = document.getElementById('input1').value;
//     document.getElementById('p2').innerHTML = x
//     document.getElementById('p2').style.color = "darkred"
// }

// function fun7(){
//     document.getElementById('input2').style.outline = "5px solid darkred"
//     document.getElementById('input2').style.borderRadius = "1px"
//     document.getElementById('input2').style.border="none"
// }
// function fun8(){
//     document.getElementById('input2').style.outline = ""
//     document.getElementById('input2').style.borderRadius = ""
//     document.getElementById('input2').style.border="2px solid black"
// }

// function fun9(){
//     // document.getElementsByTagName('b')[0].style.color="navy"

//     // alert(12345)
//    var x =  document.getElementById('select1').value;
// //    console.log(x)
//     document.getElementById('p3').innerHTML = "The sub is :" + x;
// }


function fun10(){
    // alert("hey");
    document.getElementById('textarea2').style.color = "green"
    document.getElementById('textarea2').style.background = "yellowgreen"


}






















