// function fun1(a,b){
//     var ans1 = a+b;
//     // document.write(ans1);
//     return ans1
// }

// // var res1 =  fun1(12,23);
// // document.write(res1);


// function add_num_prompt(){
//     var num1 = Number(prompt("Enter a num 1"));
//     var num2 = Number(prompt("Enter a num 2"));
//     var res1 = fun1(num1,num2);
//     document.write("the ans is :"+res1+"<br>");

// }
// add_num_prompt();


// function add_num_var(){
//     var data1 = 10;
//     var data2 = 20;
//     var final_ans = fun1(data1,data2);
//     document.write("var add is "+final_ans+"<br>");

// }
// add_num_var();


// function add_num_if_equal(){
//     var x = 20;
//     var y = 30;
//     if(x==y){
//         var res2 = fun1(x,y);
//         document.write("final ans is : "+res2+"<br>");
//     }
//     else if(x!=y){
//         var res3 = x-y
//         document.write("the sub is " +res3+"<br>")
//     }
// }
// add_num_if_equal();




// var count = 0;
// var arr1 = [1,2,3,3,4,3,5,6,3,3,3,7,3,11,3 ,11,,3,3,3,3,3];
// for(var j =0;j<arr1.length;j=j+1){
//    if(arr1[j]==3){
//     count = count +1;
//     document.write(arr1[j]+":-"+j+"<br>");

//    }
// }
// document.write("count is : "+count);


// var str_data = [" abc "," pqr "," xyz "];
// // abc
// // pqr
// // xyz


// function vowel_fun(str_data){
//     var vowel_count = 0;
//     for(var j = 0;j<str_data.length;j=j+1){
//         if(str_data[j]=="a" || str_data[j]=="i" || str_data[j]=="o"|| str_data[j]=="e" || str_data[j]=="u"){
//             vowel_count = vowel_count+ 1
//         }
//     }

//     return vowel_count;
// }


// function prompt_vowel(){
//     var user_data = prompt("Enter ");
//     var final_ans = vowel_fun(user_data.toLowerCase())
//     document.write("the num of vowel "+final_ans+"<br>");
// }

// prompt_vowel();

// function var_vowel(){
//     var user_data = "HIRAL";
//     var final_ans = vowel_fun(user_data.toLowerCase())
//     document.write("count is : "+final_ans+"<br>")
// }
// var_vowel();

// var str_data=[' abc ',' pqr ',' xyz '];

// for(var i=0;i<str_data.length;i++){
//     document.write(str_data[i].trim()+"<br>")
// }




// for(var i=10;i>=2;i--)
// {  
//     // document.write(i+"<br>");
//     var str="";
//     for(var j=1;j<=i;j++)
//     {
//         // document.write(j+"<br>");
//         str=str+j;
//     }
//     // document.write("****<br>")
//     document.write(str+"<br>");
// }

    
var numbers = [
 
    {
      "arr1" : [1,2,3,4,5,6,7,8,9,10]
    },
    {
      "arr2" : [1,2,3,4,5,6,7,8,9,10]
    },
    {
      "arr3" : [1,2,3,4,5,6,7,8,9,10]
    },
    {
      "strings" : ["a","b","c","i","o","u"]
    }
]


// Q.s 1  from arr1 print the sqaure of even number 
// Q.s 2  from arr2 print the cube of odd number
// Q.s 3  find product of all element present in arr3
// Q.s 2 from above dataset print the string which is not a vowel








var num1 = 123.4567

var x = num1.toFixed()
console.log(x,typeof(x));

















// for(var i=1; i<=10; i++) {
//     var row = "";
//     for(var j=1; j<=10-i+2; j++) {
//         row = row + j
//     }
//    document.write(row+"<br>")
// }





























