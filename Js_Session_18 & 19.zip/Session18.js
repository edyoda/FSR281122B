// function fun1(m,x){
//     // console.log(x)
//     // console.log(document.getElementById(x))
//     // console.log(m)
//     var btn_tags = document.getElementsByTagName('button');
//     for(var y = 0;y<btn_tags.length;y=y+1){
//         btn_tags[y].style.background = ""
//     }

//     m.style.background= "pink";

//     var div_tags = document.getElementsByClassName('box');
//     for(var j =0;j<div_tags.length;j=j+1){
//         div_tags[j].style.display = "none";
//     }
//     document.getElementById(x).style.display = "block";

    
// }

function first(){
    console.log("first");
}
function second(){
    console.log("second");
}
function third(){
    // console.log("third");
    for(var j =1;j<1000;j=j+1){
        console.log(j);
    }
}

first();
setTimeout(second,1000);
third();

// console.log("1234")
// console.log(98989)









