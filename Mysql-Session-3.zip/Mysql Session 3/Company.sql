CREATE DATABASE Company;

CREATE TABLE Company.Emp_info(
Emp_Id INT(20) NOT NULL auto_increment,
Emp_Name VARCHAR(20),
Emp_Profile VARCHAR(20),
Emp_Salary INT(10),
PRIMARY KEY(Emp_Id)
);


INSERT INTO  Company.Emp_info(Emp_Id,Emp_Name,Emp_Profile,Emp_Salary)
VALUES(1,"JOHN","HR",34000);


INSERT INTO  Company.Emp_info(Emp_Id,Emp_Name,Emp_Profile,Emp_Salary)
VALUES(2,"TOM","marketing",50000);

INSERT INTO  Company.Emp_info(Emp_Id,Emp_Name,Emp_Profile,Emp_Salary)
VALUES(3,"SELENA","software developer",100000);


INSERT INTO  Company.Emp_info(Emp_Id,Emp_Name,Emp_Profile,Emp_Salary)
VALUES(4,"ALEX","software tester",60000);


INSERT INTO  Company.Emp_info(Emp_Id,Emp_Name,Emp_Profile,Emp_Salary)
VALUES(5,"SAM","HR",45000);


INSERT INTO  Company.Emp_info(Emp_Id,Emp_Name,Emp_Profile,Emp_Salary)
VALUES(6,"PETER","marketing",25000);