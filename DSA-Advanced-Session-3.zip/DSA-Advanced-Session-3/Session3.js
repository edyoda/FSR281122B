// Insertion Sort 

// 5 3 1 9 8 2 4 7


// sorted      |  unsorted 

// 			5 3 1 9 8 2 4 7

// 5 | 3 1 9 8 2 4 7

// 3 5 | 1 9 8 2 4 7

// 1 3 5 | 9 8 2 4 7

// 1 3 5 9 | 8 2 4 7 

// 1 3 5 8 9  | 2 4 7

// 1 2 3 5 8 9 | 4 7

// 1 2 3 4 5 8 9 | 7

// 1 2 3 4 5 7 8 9



// 64 34 25 12 22 11

function InsertionSort(arr){
	var n = arr.length;
	for(var i = 1;i<n;i++){
		var key = arr[i] // 34
		var j = i - 1
		while(j>=0 && arr[j]>key){
			arr[j+1] = arr[j]
			j = j -1
		}
		arr[j+1] = key
	}
	console.log(arr)
	
}

var arr = [64,34, 25, 12, 22, 11]
InsertionSort(arr);



// i = 1
// arr[i] = 34
// key = arr[i]

// j = 0 
// arr[j] = 64

// 64>34
// swap 

// 34 64





// 9 1 8 2 7 3 5 6 4 
 
// 1 2 3 *4* 9 8 7 5 6

// 1 2 3 4 5 *6* 9 8 7

// 1 2 3 4 5 6 *7* 9 8

// 1 2 3 4 5 6 7 *8* 9

// 1 2 3 4 5 6 7 8 9



function QuickSort(arr){
	if(arr.length<2){
		return arr
	}
	var pivot_element = arr[arr.length-1]
	var left_arr = [];
	var right_arr = [];
	for(var i =0;i<arr.length-1;i++){
		if(arr[i]<pivot_element){
			left_arr.push(arr[i])
		}
		else if(arr[i]>pivot_element){
			right_arr.push(arr[i])
		}

	}

	return QuickSort(left_arr).concat(pivot_element,QuickSort(right_arr))
}

var arr =[ 9, 1, 8, 2, 7, 3, 5, 6, 4] 
console.log(QuickSort(arr))

























