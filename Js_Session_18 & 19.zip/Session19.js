// class Apple{
//     config1(){
//         console.log("512gb");
//     }
//     config2(){
//         console.log("256gb");
//     }
//     color(product_color){
//         // console.log("starlight");
//         console.log(product_color); 
//     }
//     inch(){
//         var a = prompt("Enter inch ");
//         console.log(a);
//     }
// }

// var macbook_air1 = new Apple();
// macbook_air1.config1();
// macbook_air1.color("starlight");
// macbook_air1.inch();
// var macbook_pro1 = new Apple();
// macbook_pro1.config2();
// macbook_pro1.inch();
// macbook_pro1.color("gold");
// var iphone_14 = new Apple();

// iphone_14.config1();


// class humans{
//     constructor(){
//         console.log(" eat sleep walk ")
//     }
//     dance(){
//         console.log('will dance');
//     }
//     swim(){
//         console.log('will swim');
//     }
// }

// var hima=new humans();
// hima.dance();
// var prathvi=new humans();
// prathvi.swim();
// var devika = new humans();

// class std_info{
//     constructor(name,age){
//         console.log("std name is "+name+" std age is "+age);
//     }
//     test_marks(Maths){
//         console.log("Maths Marks : "+Maths);
//     }
// }

// var std1 = new std_info("john",12);
// std1.test_marks(80);
// var std2 = new std_info("tom",13);
// std2.test_marks(100);
// var std3 = new std_info("selena",14);
// std3.test_marks(90);


// Map();
// filter();

// var arr1 = [11,12,13,14,15];
// arr1.map(fun1);

// function fun1(x){
//     console.log(x);
// }

// var arr2 = ["a","b","c"];
// arr2.map((y)=>{
//     console.log(y)
// });


// var arr3 = [11,12,13,14,15,16,17,18,19,20]
// var ans1 = arr3.map((z)=>{
//     return z*10
// })
// console.log(arr3);
// console.log(ans1);

// var arr4 = [11,12,13,14,15,16,17,18,19,20]
// var ans2 = arr4.filter((z)=>{
//     return z%2==0;
// })
// console.log(arr4)
// console.log(ans2)

// z*2
// z>2

// 1-operation -- map 
// 2-expression -- filter


var arr5 = [11,12,13,14,15,16,17,18,19,20]

class read_arr{
    constructor(x){
        console.log(x);
        this.val = x;
    }

    even_num(){
    //   console.log("arr 5 from even_num "+this.val)
   var ans1 = this.val.filter((z)=>{
        return z%2==0
    })
    console.log(ans1);
   
    }
    odd_num(){
        // console.log("arr 5 from odd_num "+this.val)
       var ans2 =  this.val.filter((m)=>{
            return m%2!=0
        })
        console.log(ans2);

    }
    mul(){
        // console.log("arr 5 from mul "+this.val)
       var ans3 =  this.val.map((j)=>{
            return j * 5
        })
        console.log(ans3)
    }


}
var a1 = new read_arr(arr5)
a1.even_num()
a1.odd_num()
a1.mul()














