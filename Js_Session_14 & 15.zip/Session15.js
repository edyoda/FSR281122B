var productload = ()=>{
    var a = new XMLHttpRequest();
    a.open("GET","https://fakestoreapi.com/products",true);
    a.send();
    a.onreadystatechange = function(){
        if(this.status == 200 && this.readyState == 4){
            document.getElementById('img1').style.display = "none"
            // console.log(this.responseText);
            // console.log(typeof(this.responseText))
            var data = JSON.parse(this.responseText)
            // console.log(data)
            // document.write(data)
            for(var j =0;j<data.length;j=j+1){
                // console.log(data[j]);
                var div_tag = document.createElement('div');
                div_tag.className = "product_div"
                // console.log(div_tag)
                for(var i in data[j]){
                  if(i=="image"){
                    var img_tag = document.createElement('img');
                    img_tag.src = data[j][i]
                    img_tag.className = "img_style"
                    // console.log(img_tag);
                    div_tag.appendChild(img_tag);
                  }
                  else if(i=="rating"){
                    // console.log(data[j][i])
                    for(var z in data[j][i]){
                        // console.log(data[j][i][z])
                        div_tag.innerHTML += "<br>"+z +" : "+data[j][i][z]+"<br>"
                    }
                  }

                    else{
                        div_tag.innerHTML += "<br>"+i+" --- "+data[j][i]+"<br>"
                    }
                }
                // console.log(div_tag)
                document.getElementById('main_div').appendChild(div_tag)
            }
            
        }

        else{
            document.getElementById('img1').style.display = "block"
        }
    }
   
}
productload();