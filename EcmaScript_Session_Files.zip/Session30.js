// var num1 = 12;
// document.write(num1+"<br>");
// var num1 = 13;
// document.write(num1+'<br>');

// function fun1(){
//     var num1 = 14;
//     document.write(num1+"<br>");
// }
// fun1();

// document.write(num1+"<br>");


// let str1 = "hello";
// document.write(str1+"<br>");

// // let str1 = "hey";
// // document.write(str1+"<br>");

// function fun2(){
//     let str1 = "hey"
//     document.write(str1+"<br>");
//     // let str1 = "hi"
//     // document.write(str1+"<br>");
// }

// fun2();



// var z =  10;
// z = 11;
// document.write(z+"<br>");


// let x = 20;
// x = 21;
// document.write(x+"<br>");

// const y  = "ecom_database";
// // y = "new_database";
// document.write(y+"<br>");

// with const you cannot reassign the value + you cannot reuse the var name

// var global scope , let block scope , const block scope

// const y = "psw_ecom@123";

// function fun3(){
//     const y = "psw_ecom@123";
//     document.write(y+"<br>");
//     let y = "hey kishan"
//     const x = 1235;
//     document.write(x+"<br>");
//     var kishan = "kishan@12345";
//     document.write(kishan+"<br>");
//     // var kishan = "1234"
// }

// fun3();

// reassign 

// var ==  reassign
/*
var std_name = "john";
std_name = "tom";
document.write(std_name+"<br>");

// let == reassign

let std_email = "john@gmail.com";
std_email = "tom@gmail.com";
document.write(std_email+"<br>");

// const != reassign

const std_id = 12;
std_id = 13;
document.write(std_id+"<br>");



// reuse

// can reuse var name with var keyword

var k = 100;
var k = 200;
var k = 300;

// can not reuse var name with let keyword

let j = 40;
// let j = 30;
// let j = 50;

// can not reuse var name with const keyword

const l = 23456;
// const l = 098765;*/


// var data1 = "hey";
// var data2  = "how are you ?";
// document.write("<b>"+data1+" john ! "+data2+"</b><br>");


// let data3 = "hey";
// let data4 = "how are you ?";
// document.write(`<b class="abc"><i>${data3} tom! ${data4}</b></i><br>`)



// let add_img = ()=>{
//     document.getElementById('div1').innerHTML = `<img src='img1.jpg' class='img_style'>`
// }







// function add(x,y,z){
//     var ans1 = x+y+z;
//     console.log(x,y,z)
//     document.write("the ans is : "+ans1+"<br>");
// }
// add(2,3,4);



//rest operator (...)
// let add_num = (...nums)=>{
//     console.log(nums);
//   let final_ans =  nums.reduce((count,element)=>{
//         return count = count+ element
//     },0)

//     document.write(`the final ans is :- ${final_ans} <br>`)
// }
// add_num(11,12,14,15,1567,098,67,3456,89,4567,34,124)
// add_num(12,35);
// add_num(9,9,8,6);
// add_num(2);


// let std_info = (name,sub1,email,...contact)=>{
//     document.write(`${name} , ${sub1} ,${email}, ${contact} <br>`)
// }
// std_info("john","python","john@gmail.com",78787,909090,6767);
// std_info("tom","php","tom@gmail.com",1234)



// spread operator(...)

// let arr1 = [1,2,3,4]
// let arr2 = [8,9,10]
// let arr3 = [11,12]
// let final_arr = ["a","b",...arr1,"c","d","e",...arr2,...arr3]
// document.write(final_arr+"<br>");


//object destructuring
/*
let obj1 = {
    name : "selena",
    email : "selena@gmail.com",
    contact : 345678
   
}

let{name,email,contact} = obj1
document.write(`${name} ${email} ${contact}<br>`)

// destructuring with Object inside object (nested destructuring)

let obj2 = {
    emp_name : "alex",
    emp_email : "alex@gmail.com",
    emp_contact : {
        num1 : 9090,
        num2 : 7070
    }
}

let{emp_name,emp_email,emp_contact} = obj2;
let{num1,num2} = obj2.emp_contact
document.write(`${emp_name} ${emp_email} ${num1} ${num2}`);*/



//array  destructuring + rest operator (...)
let arr_data = [11,12,13,14,15,56789,98765,4356,987,1234]
// arr_data[0] -- 11
// arr_data[1]-- 12
let[x,y,z,i,o,...new_num] = arr_data
document.write(x+"<br>");
document.write(y+"<br>");
document.write(z+"<br>");
document.write(i+"<br>");
document.write(o+"<br>");
// document.write(new_num+"<br>");
// console.log(new_num)
new_num.map((element)=>{
    document.write(element+"<br>");
})